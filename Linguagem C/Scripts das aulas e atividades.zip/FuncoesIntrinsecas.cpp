#include <stdlib.h>
#include <stdio.h>

int main(){
	
	printf("Ol� mundo.\n");
	system("pause");
	
	system("cls");
	system("pause");
		
}
